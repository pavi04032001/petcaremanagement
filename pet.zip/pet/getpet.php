<?php

include("./db.php");
$tid=$_REQUEST["p"];

$q=mysqli_query($linkid,"select cdate,rdate,oname,ptype,cost,ndays,fdate,tdate from return_det where tid=$tid");

$r=mysqli_fetch_row($q);
$oname=$r[2];
$ptype=$r[3];
$rdate=$r[1];

$q1=mysqli_query($linkid,"select count(*) from food_det where oname='$oname' and rdate='$rdate' and ptype='$ptype'");

$r2=mysqli_fetch_row($q1);
if($r2!=0)
{


$q2=mysqli_query($linkid,"select fname from food_det where oname='$oname' and rdate='$rdate' and ptype='$ptype'");

$r3=mysqli_fetch_row($q2);

	$s=$r3[0];
}	
else
	$s="-";	
	
$days=(strtotime(date($r[0]))-strtotime($r[7]))/(60*60*24);

	
echo $r[0].",".$r[2].",".$r[3].",".$r[4].",".$r[5].",".$r[6].",".$r[7].",".$s.",".$days;
?>