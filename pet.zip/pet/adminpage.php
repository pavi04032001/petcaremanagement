<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PET CARE MANAGEMENT SYSTEM</title>
<meta name="keywords" content="free design template, download web templates, Pinky Website, XHTML, CSS" />
<meta name="description" content="Pinky Template - Free CSS Template, Free XHTML CSS Design Layout" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
<body>
	<div id="templatemo_top_bg">
    	<div class="templatemo_container">
        <!--  Free CSS Template is provided by www.TemplateMo.com  -->
        	<div id="templatemo_header_top">
	        	<div id="templatemo_logo">
                	<div id="templatemo_title">
                    	<!--<span class="white">
                        	PET CARE MANAGEMENT
                        </span>
                        <span class="pink">
                        	 SYSTEM
                        </span>-->
                        <h3 style="color:white">PET CARE MANAGEMENT SYSTEM</h3>
                        
                    </div>
    	        </div>
                <div id="templatemo_search">
	                <form method="post">
						<label>Search:</label>
						<input name="search" value="Search ..." type="text" onfocus="clearText(this)" onblur="clearText(this)" class="textbox"/>
						<input type="submit" name="Search" value="GO" class="button"/>
               		</form>
                </div>
			</div><!-- End Of Header Top-->
            <div class="cleaner"></div>
            <div id="templatemo_header_bottom">
            	<div id="templatemo_menu_section">
					<ul>
		                <li><a href="view_pet.php" class="current">Pet Details</a></li>
        		        <li><a href="">Accept/Reject</a></li>
                        <li><a href="payment.php">Payment</a></li>
		                <li><a href="outstand.php">Balance</a></li>      
                        <li><a href="view_return.php">Pet Status</a></li>
		                 
                        <a href="logout.php" style="color:white;top:117px;position:absolute"><b>Logout</b></a>     
	              </ul>
                  		
				</div>
            
            <div class="cleaner"></div>
            	<div id="templatemo_header_textarea">
                	<h1><a href="#">Pets</a></h1>
                    <p>Deciding to become a pet owner requires considered thought and planning - all potential pet owners need to be sure they are really ready to take on the responsibility of owning a pet before going ahead and making a choice of breed of pet. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Children</a></h1>
                    <p>Dogs and children have a very special bond. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Interaction</a></h1>
                    <p>Dogs can provide children with companionship.  </p>                             
                </div>
            </div><!-- End Of Header Bottom-->
            <div class="cleaner_with_height"></div>
        </div><!-- End Of Container -->

    </div><!-- End Of Top Bg -->

	<div id="templatemo_middle_bg">
    	<div class="templatemo_container">
        	<div id="templatemo_three_col">
            
            	<div class="templatemo_column">
                
                	<div class="templatemo_section">
                    	<div class="templatemo_title_pink">WELCOME TO OUR WEBSITE</div>
                        <h1>Dogs and Children</h1>
                    	<p>Dogs and children have a very special bond. Dogs can provide children with companionship and loyal friendship and in return children can provide their dog with affection and endless opportunities for activity and interaction.

Young children who are bitten by dogs most often know the dog - it's either their own, a friend's or a neighbour's dog. More often than not, these bites occur in and around their own homes.</p>
					  
                    </div>
                    
                	<div class="templatemo_section">
                    
                        <div class="title">
                            <span class="title_text">OBEDIENCE</span>
                        </div>
                        
                        <p>Obedience training is essential for all dogs, regardless of breed, size or age. A few weeks of training can make your dog well behaved and easier to control. 
</p>
                      <ul>
                    	<li><a href="#">Don't approach a strange dog without permission from the owner.</a></li>
                        <li><a href="#">Do approach a dog slowly with the back of the hand extended.</a></li>
                        <li><a href="#">Do curl your fingers and allow the dog to sniff.</a></li>
                        <li><a href="#">Do stroke the dog gently on the chest, shoulder or under the chin.</a></li>
                        
                    </ul>
                                            
                    </div><!-- End Of Section -->
                    
                </div><!-- End Of Column -->
                
                <div class="templatemo_column">
	                <div class="templatemo_section">
                        <div class="title">
                            <span class="title_text"> CODES OF PRACTICE</span>
                        </div>
                        <p><img alt="Camera" src="images/1.jpg" height=100 width=100 />The Victorian Government has introduced two codes of practice for private owners of dogs and cats, to provide guidance for standards of care of your pet.  </p>
                    </div><!-- End Of Section -->
                    
                    <div class="templatemo_section">
                    
                        <div class="title">
                            <span class="title_text">CARE</span>
                        </div>
                        
                        <div class="templatemo_product_box">
                        
                        	<div class="templatemo_porduct_image">
                            	<img alt="Product" src="images/templatemo_thumb_2.jpg" />
							</div>
                            
                            <div class="templatemo_porduct_description">
                            	keep your cat confined between dusk and dawn        </div>
                            
                          <div class="cleaner_with_height"></div>
                            
                        </div>
                        
                        <div class="templatemo_product_box">
                        
                        	<div class="templatemo_porduct_image">
                            	<img alt="Product" src="images/templatemo_thumb_3.jpg" />
                            </div>
                            
                            <div class="templatemo_porduct_description">
                            	Ensure all vaccinations are up-to-date
provide your cat with a healthy varied diet
                            </div>
                            
                            <div class="cleaner_with_height"></div>
                            
                        </div>
                        
                        <div class="templatemo_product_box">
                        
                        	<div class="templatemo_porduct_image">
                            	<img alt="Product" src="images/templatemo_thumb_4.jpg" />
                            </div>
                            
                            <div class="templatemo_porduct_description">
                            	Don't squeal or jump.
Do avoid eye contact with the dog.
                            </div>
                            
                            <div class="cleaner_with_height"></div>
                            
                        </div>
                        
                        
                    </div><!-- End Of Section -->
                    
                </div><!-- End Of Column -->
                
                <div class="templatemo_column">
					<div class="templatemo_section">
                        <div class="title">
                            <span class="title_text">LATEST NEWS</span>                            
                        </div>
                        <p> 
                        	<img alt="Bug" src="images/2.jpg" />
                            <span class="info"></span><br />
                           Deciding to become a pet owner requires considered thought and planning<br />
							<span class="info"><a href="#">Read More</a></span>
						</p>
                        
                        <div class="templatemo_line"></div>
                        
                        <p> 
                        	<img alt="Butterfly" src="images/3.jpg" />
                            <span class="info"></span><br />
                           All potential pet owners need to be sure they are really ready to take on the responsibility of owning a pet <br />
							<span class="info"><a href="#">Read More</a></span>
						</p>
                        
                        <div class="templatemo_line"></div>
                        
                        <p> 
                        	<img alt="Bee" src="images/4.jpg" />
                            <span class="info"></span><br />
                            Dogs and children have a very special bond. Dogs can provide children with companionship<br />
							<span class="info"><a href="#">Read More</a></span>
						</p>
                        
                        <div class="templatemo_line"></div>
                        
                        <p> 
                        	<img alt="Lizid" src="images/6.jpg" />
                            <span class="info"></span><br />
                            Young children who are bitten by dogs most often know the dog <br />
							<span class="info"><a href="#">Read More</a></span>
						</p>
                </div>
		
            </div><!-- End Of Column -->
             <div class="cleaner"></div>
            </div><!-- End Of Three Col -->
            <div class="cleaner"></div>
        </div><!-- End Of Container -->
    </div><!-- End Of middle Bg -->

    <div id="templatemo_footer_bg">
    	<div id="templatemo_footer">
        	Copyright © 2020 <a href="#"></a> <a href="http://www.iwebsitetemplate.com" target="_parent"></a> <a href="http://www.templatemo.com" target="_parent"></a>
        </div>
    </div><!-- End Of middle footer bg -->
    <!--  Free CSS Templates by TemplateMo.com  -->
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>