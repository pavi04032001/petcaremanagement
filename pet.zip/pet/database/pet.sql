-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2021 at 05:20 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pet`
--
CREATE DATABASE IF NOT EXISTS `pet` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pet`;

-- --------------------------------------------------------

--
-- Table structure for table `food_det`
--

CREATE TABLE IF NOT EXISTS `food_det` (
  `rdate` text NOT NULL,
  `oname` text NOT NULL,
  `ptype` text NOT NULL,
  `fname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_det`
--

INSERT INTO `food_det` (`rdate`, `oname`, `ptype`, `fname`) VALUES
('27/01/2020', 'arun', 'Dog', 'oats'),
('29/01/2020', 'vicky', 'Cat', 'healthy food');

-- --------------------------------------------------------

--
-- Table structure for table `outstand`
--

CREATE TABLE IF NOT EXISTS `outstand` (
  `tid` int(11) NOT NULL,
  `oname` text NOT NULL,
  `tdate` text NOT NULL,
  `amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `outstand`
--

INSERT INTO `outstand` (`tid`, `oname`, `tdate`, `amt`) VALUES
(1, 'arun', '2020-01-29', 0),
(2, 'vicky', '2020-01-29', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `tid` int(11) NOT NULL,
  `oname` text NOT NULL,
  `ptype` text NOT NULL,
  `fname` text NOT NULL,
  `fdate` text NOT NULL,
  `tdate` text NOT NULL,
  `rdate` text NOT NULL,
  `pday` int(11) NOT NULL,
  `ndays` int(11) NOT NULL,
  `edays` int(11) NOT NULL,
  `ecost` int(11) NOT NULL,
  `fcost` int(11) NOT NULL,
  `tcost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`tid`, `oname`, `ptype`, `fname`, `fdate`, `tdate`, `rdate`, `pday`, `ndays`, `edays`, `ecost`, `fcost`, `tcost`) VALUES
(1, 'arun', 'Dog', 'oats', '2020-01-27', '2020-01-29', '2020-01-29', 1000, 2, 0, 0, 200, 2200),
(2, 'vicky', 'Cat', 'healthy food', '2020-01-29', '2020-01-31', '2020-01-29', 500, 3, -2, 0, 400, 1900);

-- --------------------------------------------------------

--
-- Table structure for table `pet_det`
--

CREATE TABLE IF NOT EXISTS `pet_det` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `cdate` text NOT NULL,
  `oname` text NOT NULL,
  `ptype` text NOT NULL,
  `cost` int(11) NOT NULL,
  `ndays` int(11) NOT NULL,
  `fdate` text NOT NULL,
  `tdate` text NOT NULL,
  `status` text NOT NULL,
  `qrpath` text NOT NULL,
  PRIMARY KEY (`tid`),
  UNIQUE KEY `tid` (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pet_det`
--

INSERT INTO `pet_det` (`tid`, `cdate`, `oname`, `ptype`, `cost`, `ndays`, `fdate`, `tdate`, `status`, `qrpath`) VALUES
(2, '27/01/2020', 'arun', 'Dog', 1000, 2, '2020-01-27', '2020-01-29', 'accept', ''),
(3, '29/01/2020', 'vicky', 'Cat', 500, 3, '2020-01-29', '2020-01-31', 'return', ''),
(4, '13/02/2021', 'vicky', 'Dog', 1000, 2, '2021-02-13', '2021-02-15', '-', 'uploads////1613225523qr.png');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE IF NOT EXISTS `receipt` (
  `tid` int(11) NOT NULL,
  `oname` text NOT NULL,
  `ctype` text NOT NULL,
  `cno` text NOT NULL,
  `tdate` text NOT NULL,
  `amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `res_det`
--

CREATE TABLE IF NOT EXISTS `res_det` (
  `rdate` text NOT NULL,
  `oname` text NOT NULL,
  `ptype` text NOT NULL,
  `cost` int(11) NOT NULL,
  `ndays` int(11) NOT NULL,
  `fdate` date NOT NULL,
  `tdate` date NOT NULL,
  `status` text NOT NULL,
  `descr` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `res_det`
--

INSERT INTO `res_det` (`rdate`, `oname`, `ptype`, `cost`, `ndays`, `fdate`, `tdate`, `status`, `descr`) VALUES
('', 'arun', 'Dog', 1000, 2, '2020-01-27', '2020-01-29', 'accept', 'sdfdf'),
('27/01/2020', 'arun', 'Dog', 1000, 2, '2020-01-27', '2020-01-29', 'accept', 'sdfdf'),
('27/01/2020', 'arun', 'Dog', 1000, 2, '2020-01-27', '2020-01-29', 'accept', 'ad'),
('29/01/2020', 'vicky', 'Cat', 500, 3, '2020-01-29', '2020-01-31', 'accept', 'accept this pet');

-- --------------------------------------------------------

--
-- Table structure for table `return_det`
--

CREATE TABLE IF NOT EXISTS `return_det` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `cdate` text NOT NULL,
  `rdate` text NOT NULL,
  `oname` text NOT NULL,
  `ptype` text NOT NULL,
  `cost` int(11) NOT NULL,
  `ndays` int(11) NOT NULL,
  `fdate` text NOT NULL,
  `tdate` text NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `return_det`
--

INSERT INTO `return_det` (`tid`, `cdate`, `rdate`, `oname`, `ptype`, `cost`, `ndays`, `fdate`, `tdate`) VALUES
(1, '2020-01-29', '27/01/2020', 'arun', 'Dog', 1000, 2, '2020-01-27', '2020-01-29'),
(2, '2020-01-29', '29/01/2020', 'vicky', 'Cat', 500, 3, '2020-01-29', '2020-01-31');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` text NOT NULL,
  `addr` text NOT NULL,
  `city` text NOT NULL,
  `uname` text NOT NULL,
  `pass` text NOT NULL,
  `cpass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `addr`, `city`, `uname`, `pass`, `cpass`) VALUES
('arun', 'arun cottage', 'madurai', 'arun', 'arun', 'arun'),
('vicky', 'vicky cottage', 'madurai', 'vicky', 'vicky', 'vicky'),
('mala', 'mala cottage', 'madurai', 'mala', 'bWFsYQ==', 'bWFsYQ==');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
