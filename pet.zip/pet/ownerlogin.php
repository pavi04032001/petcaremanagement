<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PET CARE MANAGEMENT SYSTEM</title>
<meta name="keywords" content="free design template, download web templates, Pinky Website, XHTML, CSS" />
<meta name="description" content="Pinky Template - Free CSS Template, Free XHTML CSS Design Layout" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
<body>
	<div id="templatemo_top_bg">
    	<div class="templatemo_container">
        <!--  Free CSS Template is provided by www.TemplateMo.com  -->
        	<div id="templatemo_header_top">
	        	<div id="templatemo_logo">
                	<div id="templatemo_title">
                    	<!--<span class="white">
                        	PET CARE MANAGEMENT
                        </span>
                        <span class="pink">
                        	 SYSTEM
                        </span>-->
                        <h3 style="color:white">PET CARE MANAGEMENT SYSTEM</h3>
                        
                    </div>
    	        </div>
                <div id="templatemo_search">
	                <form method="post">
						<label>Search:</label>
						<input name="search" value="Search ..." type="text" onfocus="clearText(this)" onblur="clearText(this)" class="textbox"/>
						<input type="submit" name="Search" value="GO" class="button"/>
               		</form>
                </div>
			</div><!-- End Of Header Top-->
            <div class="cleaner"></div>
            <div id="templatemo_header_bottom">
            	<div id="templatemo_menu_section">
					<ul>
		                <li><a href="homepage.php" class="current">Home</a></li>
        		        <li><a href="adminlogin.php">Admin</a></li>
		                <li><a href="#">Owner</a></li>      
	              </ul>
				</div>
            
            <div class="cleaner"></div>
            	<div id="templatemo_header_textarea">
                	<h1><a href="#">Pets</a></h1>
                    <p>Deciding to become a pet owner requires considered thought and planning - all potential pet owners need to be sure they are really ready to take on the responsibility of owning a pet before going ahead and making a choice of breed of pet. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Children</a></h1>
                    <p>Dogs and children have a very special bond. </p>
                    
                    <div class="line"></div>
                    
                    <h1><a href="#">Interaction</a></h1>
                    <p>Dogs can provide children with companionship. </p>                             
                </div>
            </div><!-- End Of Header Bottom-->
            <div class="cleaner_with_height"></div>
        </div><!-- End Of Container -->

    </div><!-- End Of Top Bg -->

	<div id="templatemo_middle_bg">
    	<div class="templatemo_container">
        	<div id="templatemo_three_col">
            
            	<div>
                
                	<div>
                    	<form method="post">
<table align="center" cellspacing="10">
<tr>
<th colspan="2">Owner Login Page</th>
</tr>
<tr>
<td>Enter the User Name</td>
<td><input type="text" name="t1"></td>
</tr>
<tr>
<td>Enter the Password</td>
<td><input type="password" name="t2"></td>
</tr>
<tr>
<td colspan="2" align="center"><a href="owner_reg.php">Sign Up</a>&nbsp;&nbsp;<input type="submit" name="submit"></td>
</tr>
</tr>
</table>
</form>
<?php
$r1=0;
session_start();
include("./db.php");
if(isset($_POST['submit'])) 
{
	$uname=$_POST['t1'];
	$pwd=$_POST['t2'];

	/*$rs=mysqli_query($linkid,"select uname,pass from user");
	
	$r=mysqli_fetch_row($rs);
	
	if($r[0]==1)
	{
	$_SESSION['owner']=$uname;
	header('Location:ownerpage.php');
	}
	else
	{
	header('Location:ownerlogin.php');
	}	*/
	
	$rs=mysqli_query($linkid,"select uname,pass from user");
	
	while($r=mysqli_fetch_row($rs))
	{	
		if($r[0]==$uname && base64_decode($r[1])==$pwd)
		{
			$r1=1;
			break;
		}
		
	}
	if($r1==1)
	{
	$_SESSION['owner']=$uname;
	header('Location:ownerpage.php');
	}
	else
	{
	header('Location:ownerlogin.php');
	}	
	
}
?>
            
					  
                    </div>      
                    
                </div><!-- End Of Column -->
                
                
		
            </div><!-- End Of Column -->
             <div class="cleaner"></div>
            </div><!-- End Of Three Col -->
            <div class="cleaner"></div>
        </div><!-- End Of Container -->
    </div><!-- End Of middle Bg -->

    <div id="templatemo_footer_bg">
    	
    </div><!-- End Of middle footer bg -->
    <!--  Free CSS Templates by TemplateMo.com  -->
<div align=center><a href='http://all-free-download.com/free-website-templates/'></a></div></body>
</html>